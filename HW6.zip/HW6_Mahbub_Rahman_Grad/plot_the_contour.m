
% Display a scatter plot of the two distributions.
function [] =plot_the_contour(X,mu,sigma,cc)
arrz=cell(cc,1);
arrZ=cell(cc,1);

    figure;
    
    
    hold off;
    plot(X(:, 1), X(:, 2), 'bo');
    hold on;
    %plot(X2(:, 1), X2(:, 2), 'ro');

    set(gcf,'color','white') % White background for the figure.

     gridSize = 100;
    u = linspace(-6, 6, gridSize);
    [A B] = meshgrid(u, u);
    gridX = [A(:), B(:)];

    
    
for jj=1:cc 
    plot(mu(jj,1), mu(jj,2), 'kx','LineWidth',2);
    arrz{jj} = gaussianND(gridX, mu(jj, :), sigma{jj}); 
  
    arrZ{jj} = reshape(arrz{jj}, gridSize, gridSize);
   
    [C, h] = contour(u, u, arrZ{jj});
     h.LineColor = [0 0.6 0];
     axis([-6 6 -6 6])

end
    
  title(['Original Data and Estimated PDFs with num cluster= ',num2str(cc)]);
    %title('Original Data and Estimated PDFs');
end