% test classifier on datatest.txt

function table4=test_my_model(all_feature_Thold,rows)

%% Setup the Import Options
opts = delimitedTextImportOptions("NumVariables", 8);

% Specify range and delimiter
opts.DataLines = [2, Inf];
opts.Delimiter = ",";

% Specify column names and types
opts.VariableNames = ["Serial_Number","date", "Temperature", "Humidity", "Light", "CO2", "HumidityRatio", "Occupancy"];
opts.VariableTypes = ["double", "datetime", "double", "double", "double", "double", "double", "double"];
opts = setvaropts(opts, 2, "InputFormat", "yyyy-MM-dd HH:mm:ss");
opts.ExtraColumnsRule = "ignore";
opts.EmptyLineRule = "read";

% Import the data
Test_data = readtable("datatest.txt", opts);


disp('Performance result on Test dataset')

testperf = zeros(5,5);
for i=1:5
    predictlabel = zeros(length(Test_data{:,i+2}),1);
    predictlabel(Test_data{:,i+2}>all_feature_Thold(i)) = 1;
    prfmnc = error_measure(predictlabel,Test_data{:,8});
    testperf(i,:) = [all_feature_Thold(i) prfmnc.errorRate prfmnc.recall prfmnc.precision prfmnc.specificity];
end
table4 = table(testperf(:,1), testperf(:,2), testperf(:,3), testperf(:,4), testperf(:,5), 'RowNames',rows);
table4.Properties.VariableNames = {'Threshold' 'Error_Rate' 'Recall' 'Precision','Specificity'}