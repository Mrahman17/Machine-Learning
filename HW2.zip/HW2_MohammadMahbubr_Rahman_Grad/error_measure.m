% =========================================================================
% This Function measures the performance matric for a classifier
% Inputs: True labels, Predicted labels
% output: struc variable that contains all four perf. metric
% =========================================================================

function perf_Meas = error_measure(predicted_labels,true_labels)
    predicted_labels = predicted_labels*2;
    diff = predicted_labels-true_labels;
    N = length(predicted_labels);
    TP = length(find(diff==1)); % True POsitive
    TN = length(find(diff==0)); % True Negative
    FP = length(find(diff==2)); % False Positive
    FN = length(find(diff==-1)); % False Negative
    perf_Meas.errorRate = (FN+FP)/N;
    perf_Meas.recall = TP/(TP+FN);
    perf_Meas.precision = TP/(TP+FP);
    perf_Meas.specificity = TN/(TN+FP);
    
end