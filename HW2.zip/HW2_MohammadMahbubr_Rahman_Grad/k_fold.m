
% =========================================================================
% This function implement k-fold algorithm
% inputs: Positive label indices, number of folds
% output: Randomly suffled indices of output label
% =========================================================================
function idx = k_fold(O_index,K)
    idx = zeros(length(O_index),1);
    % number of occupied and non occupied indices
   occ_idx = length(find(O_index==1));
   NonOcc_idx = length(find(O_index==0));
   
   % Randomize occupied indicies
   indices1 = zeros(occ_idx+mod(occ_idx,K),1);
   for  i=1:ceil(occ_idx/K)
       rng(sum('MahbuburRahman'));
       randind = randperm(K);
       indices1((i-1)*K+1:i*K) = randind; 
   end
   ind1 = indices1(1:occ_idx);
   
   %Randomize non-occupied indices
   indices2 = zeros(NonOcc_idx+mod(NonOcc_idx,K),1);
   for  i=1:ceil(NonOcc_idx/K)
       randind = randperm(K);
       indices2((i-1)*K+1:i*K) = randind; 
   end
   ind2 = indices2(1:NonOcc_idx);
   idx(O_index==1)=ind1;
   idx(O_index==0)=ind2;
end