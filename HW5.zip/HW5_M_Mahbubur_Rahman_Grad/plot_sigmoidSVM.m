% =========================================================================
% This function takes inputs from sigmoid SVM grid search and plot the accurace
% with imagesc 
% inputs:
% acc= accuracy/Number of support vector
% coeff= coefficient vector from coarse search or fine search
% gamma_vec= gamma vector used in sigmoid SVM
% title= title of the plot
% =========================================================================
function []=plot_sigmoidSVM(acc,gamma_vec,coeff_vec,titleStr)



imagesc(acc); colormap('jet'); colorbar;
    set(gca,'XTick',1:length(gamma_vec))
    set(gca,'XTickLabel',gamma_vec)
    xlabel('Gamma');
    set(gca,'YTick',1:length(coeff_vec))
    set(gca,'YTickLabel',coeff_vec)
    ylabel('coefficient');
    title(titleStr)
end