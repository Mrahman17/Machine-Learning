
% ==============================================================================
% This function apply grid search for RBF kernel
% It takes cost vector, gamma vector, data matix, true labels, folds as input
% the output of this function is the accuracy, number of SV and o/p labels
% the output is the average accross all the folds
%===============================================================================

function [Accu,NumSupportVec, output_Label] = RBF_GridSearch (costVec,gammaVec,dataMtrx,labels,CV_fold)
    numcost = length(costVec);
    numgamma = length(gammaVec);
    % initilization to take average later over all the folds
    Accu = zeros(numgamma,numcost);
    NumSupportVec = zeros(numgamma,numcost);
    Numfold = CV_fold.NumTestSets;
    output_Label = zeros(length(labels),1);

for gamma_Idx = 1:numgamma
    gamma = gammaVec(gamma_Idx);
    
    for cost_Idx = 1:numcost
        cost = costVec(cost_Idx);        
        modelParam = ['-s 0 -t 2 -c ',num2str(cost),' -g ',num2str(gamma)];
        fold_Acc = zeros(1,Numfold);
        fold_NSV = zeros(1,Numfold);
        
        for i = 1:Numfold
            train_Label = labels(CV_fold.training(i),:);
            trainset = dataMtrx(CV_fold.training(i),:);
            test_Label = labels(CV_fold.test(i),:);
            testset = dataMtrx(CV_fold.test(i),:);
            model = svmtrain(train_Label, trainset, modelParam);
            [predict_label, accuracy, ~] = svmpredict(test_Label, testset, model);
            fold_Acc(i) = accuracy(1,1);
            fold_NSV(i) = model.totalSV;
            output_Label(CV_fold.test(i)) = predict_label;
        end
        
        Accu(gamma_Idx,cost_Idx) = mean(fold_Acc);
        NumSupportVec(gamma_Idx,cost_Idx) = mean(fold_NSV);
    end
end
end