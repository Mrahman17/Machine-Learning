% ==============================================================================
% This function apply grid search for linear kernel
% It takes cost vector, data matix, true labels, folds as input
% the output of this function is the accuracy, number of SV and o/p labels
% the output is the average accross all the folds
%===============================================================================


function [Accu,NumSupportVec,output_Label] = linear_GridSearch (costVec,dataMtrx,labels,CV_folds)
    numcost = length(costVec);
    % initilization the output vectors for each folds and store average at
    % the end
    Accu = zeros(1,numcost);
    NumSupportVec = zeros(1,numcost);
    Numfold = CV_folds.NumTestSets;
    output_Label = zeros(length(labels),1);
    
    % over each cost value
    for cost_Idx = 1:numcost
        cost = costVec(cost_Idx);
        modelParam = ['-s 0 -t 0 -c ',num2str(cost)];
        fold_Acc = zeros(1,Numfold);
        fold_NSV = zeros(1,Numfold);
        
        % Over each fold
        for i = 1:Numfold
            train_Label = labels(CV_folds.training(i),:);
            trainset = dataMtrx(CV_folds.training(i),:);
            test_Label = labels(CV_folds.test(i),:);
            testset = dataMtrx(CV_folds.test(i),:);
            model = svmtrain(train_Label, trainset, modelParam);
            [predict_label, accuracy, ~] = svmpredict(test_Label, testset, model);
            fold_Acc(i) = accuracy(1,1);
            fold_NSV(i) = model.totalSV;
            output_Label(CV_folds.test(i)) = predict_label;
        end
        
        Accu(cost_Idx) = mean(fold_Acc);
        NumSupportVec(cost_Idx) = mean(fold_NSV);
    end
end