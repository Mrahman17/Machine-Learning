

function []= plot_linearSVM(cost_vec,acc_or_numSVM,titleStr,label_y)
semilogx(cost_vec,acc_or_numSVM,'LineWidth',2); 
    xlabel('Cost');
    if label_y ==1
        ylabel('Accuracy');
    else
        ylabel('Number of Support Vectors');
    end
        
    title(titleStr)
    grid on; grid minor;