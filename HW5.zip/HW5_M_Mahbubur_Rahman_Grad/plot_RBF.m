% =========================================================================
% This function takes inputs from RBM SVM grid search and plot the accurace
% with imagesc 
% inputs:
% acc= accuracy/Number of support vector
% cost_vec= cost vector from coarse search or fine search
% gamma_vec= gamma vector used in RBM
% title= title of the plot
% =========================================================================
function []=plot_RBF(acc,cost_vec,gamma_vec,titleStr)



imagesc(acc); colormap('jet'); colorbar;
    set(gca,'XTick',1:length(cost_vec))
    set(gca,'XTickLabel',cost_vec)
    xlabel('Cost');
    set(gca,'YTick',1:length(gamma_vec))
    set(gca,'YTickLabel',gamma_vec)
    ylabel('Gamma');
    title(titleStr)
end