
% =========================================================================
% This code use LibSVM toolbox to classify Opti-digits dataset 
% Linear, RBF and Sigmoid SVM has been implemented
% 5_fold cross validation has been used  
% PCA from homework 4 has been used to reduce feature vector
% 4 feature vetors [32,16,8,4] has been considered
% =========================================================================

clear; close all; clc;

load 264_optdigits


total_folds = 5; % number of fold
CVP_folds = cvpartition(class_label,'k',total_folds);

% dimentionality reduction using PCA
dims = [32,16,8,4];
% For each reduced data matrix, implemetion kernel svm
for dimIdx =1:length(dims) % select any dimention by 1,2,3
    [Dim_reduceData, ~, ~] = my_pca(data,dims(dimIdx));

 % ========================================================================  
 % linear SVM
 % ========================================================================
   %Search for optimal cost corresponds to max accuracy using coarse Search
    cost_linear = logspace(-5,6,12);
    [Accu,Num_SupportVec,~] = linear_GridSearch(cost_linear,Dim_reduceData,class_label,CVP_folds);
   
    figure; y_label=1; titlestr='Accuracy Vs Cost for linear SVM coarse search'; 
    plot_linearSVM(cost_linear,Accu,titlestr,y_label)
    
    figure;  y_label=2; titlestr='Number of Support Vectors Vs Cost';
    plot_linearSVM(cost_linear,Num_SupportVec,titlestr,y_label);
    
    % Using fine Search for cost (C)
    [~,ind] = max(Accu);
    cost = cost_linear(ind);
    fine_search_vect=[0.5:0.2:1 1:2:5]; %define a vector around coarse search cost value for fine search
    finecostVec = cost*fine_search_vect;
    [Accu,Num_SupportVec,~] = linear_GridSearch(finecostVec,Dim_reduceData,class_label,CVP_folds);
   
    figure; y_label=1;titlestr='Accuracy Vs Cost for fine search';
    plot_linearSVM(finecostVec,Accu,titlestr,y_label);
    
    figure; y_label=2;titlestr='Number of Support Vectors Vs Cost for fine search';
    plot_linearSVM(finecostVec,Num_SupportVec,titlestr,y_label);
    
    linear_Accu(dimIdx) = max(Accu);
    if dims(dimIdx)==32
        [maxAccu,ind] = max(Accu);
        lin_max_acc= maxAccu;
        lin_cost =finecostVec(ind);
        lin_num_supportVect= Num_SupportVec(ind);

        [~,~,predict_lb] = linear_GridSearch(finecostVec(ind),Dim_reduceData,class_label,CVP_folds);
        Cm_linear = confusionmat(class_label,predict_lb);
    end
    
 % =======================================================================================================   
 % RBF SVM
 % =======================================================================================================
    % coarse Search
    costVec = logspace(-3,6,10);
    gammaVec = logspace(-6,1,8);
    [Accu,NumSupportVec,~] = RBF_GridSearch(costVec,gammaVec,Dim_reduceData,class_label,CVP_folds);

    figure;
    titlestr='Accuracy';
    plot_RBF(Accu,costVec,gammaVec,titlestr)

    figure;
    titlestr='Number of Support Vectors';
    plot_RBF(NumSupportVec,costVec,gammaVec,titlestr)

    %fine Search
    [~,ind] = max(Accu(:));
    [I_gamma, I_cost] = ind2sub(size(Accu),ind);
    cost = costVec(I_cost);
    gamma = gammaVec(I_gamma);
    finecostVec = cost*fine_search_vect;
    finegammaVec = gamma*fine_search_vect;
    [Accu,NumSupportVec,~] = RBF_GridSearch(finecostVec,finegammaVec,Dim_reduceData,class_label,CVP_folds);

    figure;
    titlestr='Accuracy in fine search';
    plot_RBF(Accu,finecostVec,finegammaVec,titlestr)
    
    figure;
    titlestr= 'Number of Support Vectors in fine search';
    plot_RBF(NumSupportVec,finecostVec,finegammaVec,titlestr)
    
    [maxAccu,ind] = max(Accu(:));
    RBF_Accu(dimIdx) = maxAccu;
     
     if dims(dimIdx)==32
        [I_row, I_col] = ind2sub(size(Accu),ind);
        RBF_cost = finecostVec(I_col);
        RBF_max_acc=maxAccu;
        RBF_gamma = finegammaVec(I_row);
        RBF_num_supportVect=NumSupportVec(ind);
        [~,~,predict_lb] = RBF_GridSearch(RBF_cost,RBF_gamma,Dim_reduceData,class_label,CVP_folds);

        Cm_RBF = confusionmat(class_label,predict_lb);
     end
   
  
  % ==================================================================================================  
  % Sigmoid SVM
  % ==================================================================================================
    % coarse Search
    costVec = logspace(1,6,6);
    gammaVec = logspace(-8,-2,7);
    coeffVec = logspace(-4,0,5);
    [Accu,NumSupportVec,~] = sigmoid_GridSearch(costVec,gammaVec,coeffVec,Dim_reduceData,class_label,CVP_folds);
    [~,ind] = max(Accu(:));
    [I_coff, I_gamma, I_cost] = ind2sub(size(Accu),ind);

    figure; titlestr='Accuracy';
    plot_sigmoidSVM(Accu(:,:,I_cost),gammaVec,coeffVec,titlestr)

    figure; titlestr='Number of Support Vectors';
    plot_sigmoidSVM(NumSupportVec(:,:,I_cost),gammaVec,coeffVec,titlestr)

    %fine Search
    cost = costVec(I_cost);
    gamma = gammaVec(I_gamma);
    coeff = coeffVec(I_coff);
    finecostVec = cost*fine_search_vect;
    finegammaVec = gamma*fine_search_vect;
    finecoeffVec = coeff*fine_search_vect;
    [Accu,NumSupportVec,~] = sigmoid_GridSearch(finecostVec,finegammaVec,finecoeffVec,Dim_reduceData,class_label,CVP_folds);

    [maxAccu,ind] = max(Accu(:));
    sigmoid_Accu(dimIdx) = maxAccu;
    
    if dims(dimIdx)==32
        [I_coff, I_gamma, I_cost] = ind2sub(size(Accu),ind);

        figure; titlestr='Accuracy in fine search';
        plot_sigmoidSVM(Accu(:,:,I_cost),gammaVec,coeffVec,titlestr)

        figure; titlestr='Number of Support Vectors in fine search';
        plot_sigmoidSVM(NumSupportVec(:,:,I_cost),gammaVec,coeffVec,titlestr)
        sig_max_acc=maxAccu;
        cost_sig = finecostVec(I_cost);
        gamma_sig = finegammaVec(I_gamma);
        coeff_sig = finecoeffVec(I_coff);
        sig_num_supportVect=NumSupportVec(ind);
        [~,~,predict_lb] = sigmoid_GridSearch(cost_sig,gamma_sig,coeff_sig,Dim_reduceData,class_label,CVP_folds);

        Cm_sig = confusionmat(class_label,predict_lb);
     end
   

end
% ===========================================================================================================
% Display the Confusion matrix
% ===========================================================================================================
disp('Linear confusion matrix:')
disp(Cm_linear)
disp('RBF confusion matrix:')
disp(Cm_RBF)
disp('Sigmoid confusion matrix:')
disp(Cm_sig)

% ===========================================================================================================
% Tabulate the Cost, gamma, coefficient, accuracy and num_SVM
% ===========================================================================================================
all_cost= [lin_cost, RBF_cost,cost_sig];
all_gamma=[NaN,RBF_gamma, gamma_sig];
all_coeff=[NaN,NaN, coeff_sig];
all_acc=[lin_max_acc,RBF_max_acc,sig_max_acc];
all_sv=[lin_num_supportVect,RBF_num_supportVect,sig_num_supportVect];
rows={'Linear SVM', 'RBF SVM', 'Sigmoid SVM'};
table1=table(all_cost',all_gamma',all_coeff',all_acc',all_sv','RowNames',rows);
table1.Properties.VariableNames ={'Cost', 'gamma','coefficient','Accuracy','No_SV'}

% ===========================================================================================================
% Plot Dimension vs Accuracy
% ===========================================================================================================
figure;
plot(dims,linear_Accu,'k','LineWidth',2 );
hold on;
plot(dims,RBF_Accu,'LineWidth',2);

plot(dims,sigmoid_Accu,'c','LineWidth',2);
title('Accuracy as a function of reduced feature vector')
xlabel('feature size (PCA components)');
ylabel('Accuracy');
grid on; grid minor
legend('Linear','RBF','Sigmoid')
