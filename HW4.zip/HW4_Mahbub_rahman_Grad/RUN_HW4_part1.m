clc; clear all; close all;

load 264_optdigits.mat

xxmse = zeros(1,64);
p_of_var = zeros(1,64);
%xd = zeros(length(data),64);
for i=1:64
    [~, ~, xxmse(i),eigen_vct,~] = DR_pca(data,i);
    
    p_of_var(i) = sum(eigen_vct(end-i+1:end))/sum(eigen_vct); %portion of variance
    eigenval = flipud(eigen_vct);
end

figure(1); 
subplot(311);
plot(xxmse,'mx-','linewidth',1.5, 'MarkerSize',8);
xlim([0 64]);
xlabel('# principal components')
ylabel('Reconstruction erorr')
title('Reconstruction error vs principal component','FontSize', 12)
grid on; grid minor;


subplot(312);
plot(eigenval,'mx-','linewidth',1.5)
xlim([0 64])
xlabel('EigenVectors')
ylabel('Eigenvalues')
title('Scree Graph for Optidigits','FontSize', 12)
grid on; grid minor;

subplot(313);
plot(p_of_var,'mx-','linewidth',1.5)
xlim([0 64])
xlabel('# principal components')
ylabel('Prop. of Var.')
title('Proportion of variance','FontSize', 12)
grid on; grid minor;

% =========================================================================
% Optdigits data plot in the space of Three principal components.
% =========================================================================
[xd, ~, ~, ~,~] = DR_pca(data,3);
figure;
subplot(121);
scatter3(xd(:,1),xd(:,2),xd(:,3),10,class_label,'filled')
xlabel('First eigenvector','Rotation',20)
ylabel('Second eigenvector','Rotation',-30)
zlabel('Thrid eigenvector')
title('Optdigits after PCA')
colorbar
b=200;
str_lb= num2str(class_label(1:b));

subplot(122);
scatter3(xd(1:b,1),xd(1:b,2),xd(1:b,3),10,class_label(1:b),'filled')
text(xd(1:b,1),xd(1:b,2),xd(1:b,3),str_lb,'VerticalAlignment','bottom','HorizontalAlignment','right')
xlabel('First eigenvector','rotation', 20)
    ylabel('Second eigenvector','rotation',-30)
    zlabel('Thrid eigenvector')
    title('Optdigits after PCA [200 datapoints are shown]');

% =========================================================================
% Eigen Faces
% =========================================================================
[~, ~, ~, ~,prncpl_egnvct] = DR_pca(data,8);

%eig_mean = reshape(data(1,:),[8,8]);
eig_mean = reshape(mean(data,1),[8,8]);
figure,subplot(3,3,1),
imagesc(eig_mean')
title('original digit')
colormap gray
prncpl_egnvct=fliplr(prncpl_egnvct);
for i = 1:8
    subplot(3,3,i+1)
    imagesc(reshape(prncpl_egnvct(:,i),[8,8]))
    title(['Principal component ' num2str(i)])
end