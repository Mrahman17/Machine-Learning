
function plotting_DR(mappedX,method,class_label)

% scatter3(mappedX(:,1),mappedX(:,2),mappedX(:,3),20,class_label,'filled');
%    xlabel('First eigenvector','rotation', 20)
%     ylabel('Second eigenvector','rotation',-30)
%     zlabel('Thrid eigenvector')
%     title(['Optdigits after ' method])
%     colorbar
%     
 b=100;
str_lb= num2str(class_label(1:b));

scatter3(mappedX(1:b,1),mappedX(1:b,2),mappedX(1:b,3),10,class_label(1:b),'filled')
text(mappedX(1:b,1),mappedX(1:b,2),mappedX(1:b,3),str_lb,'VerticalAlignment','bottom','HorizontalAlignment','right')
   xlabel('First eigenvector','rotation', 20)
    ylabel('Second eigenvector','rotation',-30)
    zlabel('Thrid eigenvector')
    title(['Optdigits after ' method])

end