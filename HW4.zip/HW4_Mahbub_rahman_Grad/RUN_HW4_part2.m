

clc; clear all; close all;
addpath(genpath('drtoolbox')) % add the path of toolbox

load 264_optdigits.mat
no_dims=3;
data_with_label=zeros(1934,65);
data_with_label(:,1)=class_label;
data_with_label(:,2:end)=data;
techniques={'PCA','LDA','MDS','FactorAnalysis'};

figure;
subplot(2,2,4);
for ii=1:4
    if strcmp(techniques{ii},'LDA')
        dataX=data_with_label;
    else
        dataX=data;
    end
    subplot(2,2,ii)
    mappedX_opt = compute_mapping(dataX,techniques{ii},no_dims);
    plotting_DR(mappedX_opt,techniques{ii},class_label)
end

% =========================================================================
% Compare PCA and Prob PCA
% =========================================================================

mappedX1_opt = compute_mapping(dataX,techniques{1},no_dims);
mappedX2_opt = compute_mapping(dataX,'ProbPCA',no_dims,200);

figure; 
subplot(121); plotting_DR(mappedX1_opt,techniques{1},class_label);
subplot(122); plotting_DR(mappedX2_opt,'ProbPCA',class_label);

% =========================================================================
% mystery data set
% =========================================================================
input('\n Please hit enter to proceed \n')
disp('Now working with Mystery dataset [this will take a while].......')
load Mystery_DataSet;
mystery_data=Data;
mystery_label=Label;

mappedX1_myst = compute_mapping(mystery_data,techniques{1},2);
mappedX2_myst = compute_mapping(mystery_data,'ProbPCA',2,200);
mappedX3_myst = compute_mapping(mystery_data,'SPE',3,'Global');

figure; 
subplot(131);


scatter(mappedX1_myst(1:1000,1),mappedX1_myst(1:1000,2),20,mystery_label(1:1000),'filled');
xlabel('First Eigenvector')
ylabel('2nd Eigenvector');
title('PCA')
subplot(132); 
scatter(mappedX2_myst(1:1000,1),mappedX2_myst(1:1000,2),20,mystery_label(1:1000),'filled');

xlabel('First Eigenvector')
ylabel('2nd Eigenvector');
title('Prob PCA')
subplot(133); 
scatter(mappedX3_myst(1:1000,1),mappedX3_myst(1:1000,2),20,mystery_label(1:1000),'filled');

xlabel('First Eigenvector')
ylabel('2nd Eigenvector');
title('SPE')

