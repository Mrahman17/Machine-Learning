function d = div(a,b)
% DIV Integer division
% d = div(a,b)

d = floor(a / b);        
