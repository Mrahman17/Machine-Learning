close all; clear; clc;

addpath(genpath('HMMall'));
load('hmm.mat')

%parameters to create random stochastic matrices
Ob = 3; % Number of Observations
iters = 25; % Maximum number of iteration for training.
States = 2:20; % 2-20 number of states for grid search
No_fold = 5; % 5-fold crossval

%Preallocating memory for speed up
LLhood1 = zeros(1,No_fold);
LLhood2 = zeros(1,No_fold);
LLhood_avg1 =  zeros(1,length(States));
LLhood_avg2 =  zeros(1,length(States));

cv_Pertition = cvpartition(size(data1,1),'k',No_fold);   
for st = 1:length(States) % loop for finding states
    Q = States(st); % Number of states
    for i = 1:No_fold  %loop for cross validation fold                                
        testIdx = cv_Pertition.training(i);
        trainIdx = cv_Pertition.test(i);
                  
        % Randomly initialized stochastic matrices
        rng(sum('MMahbubRahman'))
        prior0 = normalise(rand(Q,1));          %initial state probability vector
        transmat0 = mk_stochastic(rand(Q,Q));   %state transition probability matrix
        obsmat0 = mk_stochastic(rand(Q,Ob));    %observation probability matrix
        rng('default')
        % Finding the parameters for Process 1
        [LL1, prior1, transmat1, obsmat1] = dhmm_em(data1(trainIdx,:), prior0, transmat0, obsmat0, 'max_iter', iters);
        % Finding the parameters for Process 2
        [LL2, prior2, transmat2, obsmat2] = dhmm_em(data2(trainIdx,:), prior0, transmat0, obsmat0, 'max_iter', iters);
        
        %To evaluate the log-likelihood of a trained model given test data
        LLhood1(i) = dhmm_logprob(data1(testIdx,:), prior1, transmat1, obsmat1);
        LLhood2(i) = dhmm_logprob(data2(testIdx,:), prior2, transmat2, obsmat2);
        
    end
    %averaging log-likelihood
    LLhood_avg1(st)=mean(LLhood1);
    LLhood_avg2(st)=mean(LLhood2);
end

% Get the Indices of Optimal number of states for the both processes
[~, s1]=max(LLhood_avg1); 
[~, s2]=max(LLhood_avg2); 

% plot of log-likelihood values for states 2 to 20 for the both processes 
figure;
subplot(211)
plot(States,LLhood_avg1,'LineWidth',2)
xlabel('Number of hidden states')
ylabel('Log-likelihood')
title('Process 1')
xlim([min(States) max(States)])
grid on; grid minor;
subplot(212)
plot(States,LLhood_avg2,'LineWidth',2)
xlabel('Number of hidden states')
ylabel('Log-likelihood')
title('Process 2')
xlim([min(States) max(States)])
grid on; grid minor

%% Find parameters corresponds to optimal hidden states for the both processes
[Param1,Param2]=optimal_LLhood(data1,data2,s1,s2,iters,States,Ob);

%% Discrete sequence classification
% Test data set
TestData = [X1;X2;X3;X4;X5;X6];
Q1=States(s1);
Q2=States(s2);
sequence_classify(TestData,Param1,Param2,Q1,Q2)
