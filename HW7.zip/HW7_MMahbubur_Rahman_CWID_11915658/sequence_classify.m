function []=sequence_classify(TestData,param1,param2,Q1,Q2)


result = [];
fprintf('-------------------------------------------------------\n')

fprintf('Number of hidden states for Model 1 : %d \n', Q1)
fprintf('Number of hidden states for Model 2 : %d \n', Q2)
fprintf('\n')
fprintf('\n')
fprintf('Table 1: Discrete Sequence classification usign HMM\n')
fprintf('-------------------------------------------------------\n')
fprintf('Sequence \t\t : Process \n')
fprintf('---------------------------------------\n')
for i = 1:size(TestData,1)
    LLikhood1_val(i) = dhmm_logprob(TestData(i,:), param1.prior, param1.transmat, param1.obsmat);
    LLikhood2_val(i) = dhmm_logprob(TestData(i,:), param2.prior, param2.transmat, param2.obsmat);
    if (LLikhood1_val(i) > LLikhood2_val(i))
        result = 'Process1';
    else
        result = 'Process2';
    end
    fprintf('X%s \t\t\t\t : %s\n',num2str(i),result)
    fprintf('---------------------------------------\n')
end

figure; scatter(1:6,LLikhood1_val,'filled')
 hold on; scatter(1:6,LLikhood2_val,'filled')
 xlim([0 7])
 ylim([-300 -180])
 xticks([1 2 3 4 5 6])
 xticklabels({'X1','X2','X3','X4','X5','X6'})
 grid on; grid minor
 xlabel('Discrete Sequences');
 ylabel('Log-Likelihood')
 title('Sequence classification [Blue = proc.1, crimson = Proc.2]');
 legend('Process 1','Process 2')


end