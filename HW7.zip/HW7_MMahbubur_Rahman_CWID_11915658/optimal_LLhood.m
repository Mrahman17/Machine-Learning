function [Param1,Param2]=optimal_LLhood(data1,data2,c1,c2,iters,States,Ob)

% Initial parameters for process 1 with selected number of states

 rng(sum('MMahbubRahman'))
Q1 = States(c1);                           % Optimal number of states for Process 1
prior0 = normalise(rand(Q1,1));              % Prior
transmat0 = mk_stochastic(rand(Q1,Q1));       % Transition matrix
obsmat0 = mk_stochastic(rand(Q1,Ob));         % observation matrix
rng('default')

fprintf('Training Parameters to find HMM model for Process-1 with state Q = : %d \n', Q1)
[LL1_final, prior1, transmat1, obsmat1] = dhmm_em(data1, prior0, transmat0, obsmat0, 'max_iter', iters);

% Initial parameters for process 2 with selected number of states
 rng(sum('MMahbubRahman'))
Q2 = States(c2);                           % Optimal number of states for Process 2
prior0 = normalise(rand(Q2,1));              % Prior
transmat0 = mk_stochastic(rand(Q2,Q2));       % Transition matrix
obsmat0 = mk_stochastic(rand(Q2,Ob));         % observation matrix
rng('default')

fprintf('Traning Parameters for find HMM model for Process-2 with Q = : %d \n', Q2)
[LL2_final, prior2, transmat2, obsmat2] = dhmm_em(data2, prior0, transmat0, obsmat0, 'max_iter', iters);

% plotting the trained log likelihood
figure;
plot(LL1_final,'LineWidth',2);
hold on;
plot(LL2_final,'LineWidth',2)
xlabel('Number of iterations')
ylabel('Log-likelihood')
title('Log-likelhood variaiton with iterations[Blue = proc.1, Red = Proc.2]')
legend('Process-1','process-2')
grid on; grid minor

Param1.prior=prior1;
Param1.transmat=transmat1;
Param1.obsmat=obsmat1;

Param2.prior=prior2;
Param2.transmat=transmat2;
Param2.obsmat=obsmat2;

end