function predict_label=single_param_model(ds,test_data,ls,method)
% method={'Quadratic', 'linear', 'Naive Bayes', 'Euclidean'};
c1=ds(ls==1,:);
c2=ds(ls==2,:);
% train the model
N_labls = [sum(ls==1); sum(ls==2)];
N=length(ls);
P(1) = N_labls(1)/N; % probability of class 1
P(2) = N_labls(2)/N; % probability of class 2

mean1 = mean(c1)'; % estimate the mean of class1
mean2 = mean(c2)'; % estimate the mean of class2
cov1 = cov(c1);  % estimate the covariance matrix of class1
cov2 = cov(c2);  % estimate the covariance matrix of class2

% calculate inverse matrix
invs_cov1=cov1^-1; 
invs_cov2=cov2^-1;

% common covariance matrix
common_Cov=P(1)*cov1+P(2)*cov2;
invs_cmn_cov = common_Cov^-1;

g1 = zeros(N,1);
g2 = zeros(N,1);


    if contains(method,'Quadratic')
         for i=1:N
          data=test_data(i,:)';  
            g1(i) = -0.5*log(det(cov1))-0.5*(data-mean1)'*invs_cov1*(data-mean1)+log(P(1));
            g2(i) = -0.5*log(det(cov2))-0.5*(data-mean2)'*invs_cov2*(data-mean2)+log(P(2));
         end
    elseif contains(method,'linear')
        for i=1:N
        data=test_data(i,:)';
            g1(i) = -.5*(data-mean1)'*invs_cmn_cov*(data-mean1)+log(P(1));
            g2(i) = -.5*(data-mean2)'*invs_cmn_cov*(data-mean2)+log(P(2));
        end
    elseif contains(method,'Naive Bayes')
        for i=1:N
        data=test_data(i,:)';
           
            g1(i) = -.5*sum(((data-mean1)./[common_Cov(1,1); common_Cov(2,2)]).^2)+log(P(1));
            g2(i) = -.5*sum(((data-mean2)./[common_Cov(1,1); common_Cov(2,2)]).^2)+log(P(2));

        end
    else
        for i=1:N
        data=test_data(i,:)';
            g1(i) = -.5*sum((data-mean1).^2)+log(P(1));
            g2(i) = -.5*sum((data-mean2).^2)+log(P(2));
        end
    end

predict_label = ones(N,1);
predict_label(g2>g1)=2;


