
function plot_the_classes(outlabel,ds,titleString)

figure;
title(titleString);
xa=2; xb=4; ya=1; yb=3;         % coordinates of the rectangle C1

xa2=2; xb2=7; ya2=3; yb2=5;         % coordinates of the rectangle C2
hold on; plot([xa xb xb xa xa],[ya ya yb yb ya],'-');    % draw it

plot([xa2 xb2 xb2 xa2 xa2],[ya2 ya2 yb2 yb2 ya2],'-');    % draw it

for i=1:length(outlabel)
if (outlabel (i)==1); plot(ds(i,1),ds(i,2),'b+'); 
elseif (outlabel (i)==2); plot(ds(i,1),ds(i,2),'k*'); 
else
    plot(ds(i,1),ds(i,2),'go');
    
end
end
end