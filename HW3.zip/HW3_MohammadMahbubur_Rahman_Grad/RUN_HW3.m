
clc; clear all; close all
%MATLAB code to generate data:
 N=100:100:1500; % data points
 err=zeros(length(N),1);
 Acc=zeros(length(N),1);
 
 method={'Quadratic', 'linear', 'Naive Bayes', 'Euclidean'};
% ========================================================================= 
% Q2,3: choosing a model with appropriate complexity and shows accuracy
% for different number of data points
% =========================================================================
disp('---- Running--------')
for i=1:length(N)
[training_data,training_labels]=generate_data(N(i));
predict_label=single_param_model(training_data,training_data,training_labels,method{1});
perfmnc = error_measure(predict_label,training_labels);
err(i)=perfmnc.Emperical_error;
Acc(i)=1-err(i);
close all;
end
disp('Quadratic Discriminant model on different data points...')
table1 = table(N', err, Acc);
table1.Properties.VariableNames = {'Datapoints' 'Error_Rate' 'Accuracy'}

figure;plot(N,err,'LineWidth',2); title('Error vs Number of Data points');
xlabel('No of data points'); ylabel('Error');grid on;

figure;plot(N,Acc,'LineWidth',2); title('Accuracy vs Number of Data points');
xlabel('No of data points'); ylabel('Accuracy');grid on;

% =========================================================================
% Q(4)Performance of Quadratic discreminant model on test dataset
% =========================================================================
input('\n Please hit enter to proceed \n')
[training_data,training_labels]=generate_data(1000);
[test_data,test_labels]=generate_test_data(1000);
predict_test_ls=single_param_model(training_data,training_data,training_labels,method{1});
test_perfmnc = error_measure(predict_test_ls,training_labels);
disp('Error on training data')
error(1)=test_perfmnc.Emperical_error
predict_test_ls=single_param_model(training_data,test_data,training_labels,method{1});
test_perfmnc = error_measure(predict_test_ls,test_labels);
disp('error on Test dataset:')
gen_error(1)=test_perfmnc.Emperical_error


title='Prediction on test data';
plot_the_classes(predict_test_ls,test_data, title); 

disp('------------------------Graduate part of the assignment-----------------------------')

% =========================================================================
% Grad 1: Implementing all the four mathods
% =========================================================================
input('\n Please hit enter to proceed \n')
disp('Error on all methods both for trainig and testing')
% method 2: Linear
predict_test_ls=single_param_model(training_data,training_data,training_labels,method{2});
test_perfmnc = error_measure(predict_test_ls,training_labels);
error(2)=test_perfmnc.Emperical_error;

predict_test_ls=single_param_model(training_data,test_data,training_labels,method{2});
test_perfmnc = error_measure(predict_test_ls,test_labels);
gen_error(2)=test_perfmnc.Emperical_error;

%method 3: Naive Bayes
predict_test_ls=single_param_model(training_data,training_data,training_labels,method{3});
test_perfmnc = error_measure(predict_test_ls,training_labels);
error(3)=test_perfmnc.Emperical_error;

predict_test_ls=single_param_model(training_data,test_data,training_labels,method{3});
test_perfmnc = error_measure(predict_test_ls,test_labels);
gen_error(3)=test_perfmnc.Emperical_error;

% method 4: Euclidean
predict_test_ls=single_param_model(training_data,training_data,training_labels,method{4});
test_perfmnc = error_measure(predict_test_ls,training_labels);
error(4)=test_perfmnc.Emperical_error;

predict_test_ls=single_param_model(training_data,test_data,training_labels,method{3});
test_perfmnc = error_measure(predict_test_ls,test_labels);
gen_error(4)=test_perfmnc.Emperical_error;

table2 = table(method', error', gen_error');
table2.Properties.VariableNames = {'Method' 'Error_Rate' 'Generalization_Error'}

% =========================================================================
% Grad 2: Implement a classifier with Rejection
% =========================================================================
input('\n Please hit enter to proceed \n')
states={'training','testing'};
[outlabel,THold1,THold2]=train_param_model(training_data,training_data,training_labels,states{1},0,0);
test_perfmnc = error_measure(outlabel,training_labels);
disp('Error with rejection on training data:')
err_reject_train=test_perfmnc.Emperical_error

outlabel2=train_param_model(training_data,test_data,training_labels,states{2},THold1,THold2);
test_perfmnc = error_measure(outlabel2,test_labels);
disp('Error with rejection on Test data:')
err_reject_test=test_perfmnc.Emperical_error

title='Prediction with rejection on test data';
plot_the_classes(outlabel2,test_data, title); 
disp('---------Completed------------------')





                
  
       
