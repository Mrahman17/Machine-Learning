function [ds, ls]=generate_data(N)
figure('visible','off')
xa=2; xb=4; ya=1; yb=3;         % coordinates of the rectangle C1

xa2=2; xb2=7; ya2=3; yb2=5;         % coordinates of the rectangle C2
hold on; plot([xa xb xb xa xa],[ya ya yb yb ya],'-');    % draw it

plot([xa2 xb2 xb2 xa2 xa2],[ya2 ya2 yb2 yb2 ya2],'-');    % draw it

% generate positive and negative examples



ds=zeros(N,2); ls=zeros(N,1);       % labels
rng(sum('mahbuburrahman'));
for i=1:N

x=rand(1,1)*8; y=rand(1,1)*8;ds(i,1)=x; ds(i,2)=y;

% +ve if falls in the rectangle, -ve otherwise

if ((x > xa) && (y > ya) && (y < yb) && ( x < xb)) ls(i)=1; plot(x,y,'b+'); 

elseif ((x > xa2) && (y > ya2) && (y < yb2) && ( x < xb2)) ls(i)=2; plot(x,y,'k*');

else ls(i)=0; plot(x,y,'go'); end;   

end;
end