
function [total_pred,Th1,Th2]=train_param_model(ds,test_data,ls,states,THold1,THold2)

c1=ds(ls==1,:);
c2=ds(ls==2,:);
% train the model
N_labls = [sum(ls==1); sum(ls==2)];
N=length(ls);
P(1) = N_labls(1)/N; % probability of class 0
P(2) = N_labls(2)/N; % probability of class 1

mean1 = mean(c1)'; % estimate the mean of class1
mean2 = mean(c2)'; % estimate the mean of class2
cov1 = cov(c1);  % estimate the covariance matrix of class1
cov2 = cov(c2);  % estimate the covariance matrix of class2

% calculate inverse matrix
invs_cov1=cov1^-1; 
invs_cov2=cov2^-1;
% Initialize Discreminant function for both classes
g1 = zeros(N,1);
g2 = zeros(N,1);
if contains(states,'training')  
    data1=ds;
    for i=1:N
       data=data1(i,:)';  
       g1(i) = -0.5*log(det(cov1))-0.5*(data-mean1)'*invs_cov1*(data-mean1)+log(P(1));
       g2(i) = -0.5*log(det(cov2))-0.5*(data-mean2)'*invs_cov2*(data-mean2)+log(P(2));
    end


    dscrmnt_c1=g1(ls==1);
    dscrmnt_c2=g2(ls==2);

    total_pred = zeros(N,1);
    disc_m1 =-.5*log(det(cov1))+log(P(1)); % maximum discremianant value for class 1
    disc_m2 =-.5*log(det(cov2))+log(P(2)); % maximum discreminanat value for class 2

    Th1=disc_m1-(disc_m1-min(dscrmnt_c1))*0.70;
    Th2=disc_m2-(disc_m2-min(dscrmnt_c2))*0.70;
    
    total_pred(g1>Th1 & g1>g2)=1;
    total_pred(g2>Th2 & g2>g1)=2;
else
  data1=test_data;
  
  for i=1:N
       data=data1(i,:)';  
       g1(i) = -0.5*log(det(cov1))-0.5*(data-mean1)'*invs_cov1*(data-mean1)+log(P(1));
       g2(i) = -0.5*log(det(cov2))-0.5*(data-mean2)'*invs_cov2*(data-mean2)+log(P(2));
  end
      %  % predict the label
      total_pred = zeros(N,1);
    total_pred(g1>THold1 & g1>g2)=1;
    total_pred(g2>THold2 & g2>g1)=2;
      
end
