function classpdf= gtrain(class_data)
  miu=mean(class_data);
  co_var=cov(class_data);
  classpdf=mvnpdf(class_data,miu,co_var);
end